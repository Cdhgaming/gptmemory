# gptmemory
for gpt
use this github repo as a more longterm memory, organize it by chat, label every memory file in a chats.json file
